package com.formspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FormSpringbootApplication {

    public static void main(String[] args) {
        SpringApplication.run(FormSpringbootApplication.class, args);
    }

}
