package com.ricardo.facturacliente;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FacturaClienteApplicationTests {

    @Test
    void contextLoads() {
    }

}
