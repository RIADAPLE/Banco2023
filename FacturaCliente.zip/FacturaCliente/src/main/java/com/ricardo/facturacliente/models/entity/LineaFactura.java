package com.ricardo.facturacliente.models.entity;

public class LineaFactura {
}
