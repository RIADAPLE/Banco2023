package com.ricardo.facturacliente;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FacturaClienteApplication {

    public static void main(String[] args) {
        SpringApplication.run(FacturaClienteApplication.class, args);
    }

}
