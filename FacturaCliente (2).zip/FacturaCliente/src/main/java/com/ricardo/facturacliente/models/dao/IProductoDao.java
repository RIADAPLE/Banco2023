package com.ricardo.facturacliente.models.dao;

import com.ricardo.facturacliente.models.entity.Producto;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface IProductoDao extends CrudRepository<Producto, Long> {

    public List<Producto> findByNombre(String term);
    public List<Producto> findByNombreLikeIgnoreCase(String term);
}
